package repositorio;

import dominio.SitioTuristico;


public class RepositorioMemoriaSitioTuristico extends RepositorioMemoria<SitioTuristico>{
	public RepositorioMemoriaSitioTuristico(){
		super();
	}
}
