package dominio;

public enum EstadoIncidencia {
	PENDIENTE,CANCELADA,ASIGNADA,RESUELTA;

}
