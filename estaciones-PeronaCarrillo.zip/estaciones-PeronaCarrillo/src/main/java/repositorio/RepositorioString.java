package repositorio;

public interface RepositorioString<T> extends Repositorio<T, String> {

}
