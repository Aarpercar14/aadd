package dominio;

import repositorio.RepositorioMemoria;

public class RepositorioMemoriaEstacion extends RepositorioMemoria<Estacionamiento>{
	
	public RepositorioMemoriaEstacion() {
		super();
	}

}
