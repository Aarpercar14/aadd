package dominio;

import repositorio.RepositorioMemoria;


public class RepositorioMemoriaSitioTuristico extends RepositorioMemoria<SitioTuristico>{
	public RepositorioMemoriaSitioTuristico(){
		super();
	}
}
